<?php
/**
 * ClientSnapshot Pro - Directory Index
 *
 * @package    WHMCS
 * @subpackage Addon Modules
 * @author     SKYRHRG Technologies System
 */

header("Location: ../../../index.php");
exit;
