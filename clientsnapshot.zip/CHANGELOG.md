# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.0] - 2026-01-23

### Added
- Initial release of ClientSnapshot Pro
- Dashboard view with client statistics
- DataTable integration for searching and sorting clients
- CSV export functionality
- Excel export functionality using SpreadsheetML
- Admin dashboard widget hook
- Responsive design for mobile support
